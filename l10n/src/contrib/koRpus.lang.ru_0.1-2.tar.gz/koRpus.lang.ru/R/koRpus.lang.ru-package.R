#' \packageDescription{koRpus.lang.ru}
#'
#' The DESCRIPTION file:
#' \tabular{ll}{
#' Package: \tab koRpus.lang.ru\cr
#' Type: \tab Package\cr
#' Version: \tab 0.1-2\cr
#' Date: \tab 2020-10-24\cr
#' Depends: \tab R (>= 3.1),koRpus (>= 0.11-2)\cr
#' Encoding: \tab UTF-8\cr
#' License: \tab GPL (>= 3)\cr
#' LazyLoad: \tab yes\cr
#' URL: \tab https://reaktanz.de/?c=hacking&s=koRpus\cr
#' }
#'
#' @title
#' \packageTitle{koRpus.lang.ru}
#' @author
#' \packageAuthor{koRpus.lang.ru}
#'
#' Maintainer: \packageMaintainer{koRpus.lang.ru}
"_PACKAGE"
