#' \packageDescription{koRpus.lang.es}
#'
#' The DESCRIPTION file:
#' \tabular{ll}{
#' Package: \tab koRpus.lang.es\cr
#' Type: \tab Package\cr
#' Version: \tab 0.1-2\cr
#' Date: \tab 2020-10-24\cr
#' Depends: \tab R (>= 3.1),koRpus (>= 0.11-2)\cr
#' Encoding: \tab UTF-8\cr
#' License: \tab GPL (>= 3)\cr
#' LazyLoad: \tab yes\cr
#' URL: \tab https://reaktanz.de/?c=hacking&s=koRpus\cr
#' }
#'
#' @title
#' \packageTitle{koRpus.lang.es}
#' @author
#' \packageAuthor{koRpus.lang.es}
#'
#' Maintainer: \packageMaintainer{koRpus.lang.es}
"_PACKAGE"
