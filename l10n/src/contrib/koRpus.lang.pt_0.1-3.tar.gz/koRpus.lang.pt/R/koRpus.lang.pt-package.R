#' \packageDescription{koRpus.lang.pt}
#'
#' The DESCRIPTION file:
#' \tabular{ll}{
#' Package: \tab koRpus.lang.pt\cr
#' Type: \tab Package\cr
#' Version: \tab 0.1-3\cr
#' Date: \tab 2020-10-24\cr
#' Depends: \tab R (>= 3.1),koRpus (>= 0.11-2)\cr
#' Encoding: \tab UTF-8\cr
#' License: \tab GPL (>= 3)\cr
#' LazyLoad: \tab yes\cr
#' URL: \tab https://reaktanz.de/?c=hacking&s=koRpus\cr
#' }
#'
#' @title
#' \packageTitle{koRpus.lang.pt}
#' @author
#' \packageAuthor{koRpus.lang.pt}
#'
#' Maintainer: \packageMaintainer{koRpus.lang.pt}
"_PACKAGE"
